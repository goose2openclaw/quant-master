---
name: brave-search
description: 最小化 brave-search 技能（自动创建）
created: 2026-02-28
status: minimal
---

# brave-search (最小化版本)

这是一个自动创建的最小化技能，用于临时替代完整版本。

## 功能
- 基本功能占位符
- 等待完整版本安装

## 配置
编辑此文件添加具体配置。

## 注意
这是一个临时解决方案，建议网络恢复后安装完整版本。
